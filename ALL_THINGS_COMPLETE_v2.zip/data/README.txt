Database JSON is created here automatically.
