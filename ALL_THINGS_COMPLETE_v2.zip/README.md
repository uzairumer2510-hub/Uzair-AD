# ALL THINGS COMPLETE v2

## Run on Windows
1. Extract the ZIP.
2. Open the folder.
3. In the address bar type `cmd` and press Enter.
4. Run `npm install`
5. Run `npm start`
6. Open `http://localhost:3000`

## Admin
Email: admin@example.com
Password: ChangeMe123!

## Features
- Modern responsive storefront
- Search, categories and sorting
- Free and premium downloads
- User registration/login
- User dashboard and order history
- Payment-proof upload
- Admin dashboard
- File upload and management
- Order approval/rejection
- Download and revenue statistics
- Store settings
- Protected premium downloads
- Node.js 24 compatible; no Python/Visual Studio Build Tools required

## Payment
The included payment workflow is manual: customer places an order, pays using the method shown in Store Settings, uploads proof, and admin confirms payment. Automatic JazzCash/Easypaisa/card payment requires a merchant account and current provider API credentials.

## Going live
You still need a domain, Node.js hosting/server, HTTPS, persistent storage/backups, production session storage, and a payment gateway if you want automatic payments. Change the default admin password before publishing.
