Runtime uploads are stored here.
